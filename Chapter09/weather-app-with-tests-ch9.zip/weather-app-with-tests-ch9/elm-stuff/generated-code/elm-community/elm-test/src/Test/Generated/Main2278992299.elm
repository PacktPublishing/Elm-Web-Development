module Test.Generated.Main2278992299 exposing (main)

import CustomExpectations

import Test.Reporter.Reporter exposing (Report(..))
import Console.Text exposing (UseColor(..))
import Test.Runner.Node
import Test
import Json.Encode

main : Test.Runner.Node.TestProgram
main =
    [     Test.describe "CustomExpectations" [CustomExpectations.suite] ]
        |> Test.concat
        |> Test.Runner.Node.runWithOptions { runs = Nothing, report = (ConsoleReport Monochrome), seed = Nothing, processes = 2, paths = ["tests/CustomExpectations.elm"]}