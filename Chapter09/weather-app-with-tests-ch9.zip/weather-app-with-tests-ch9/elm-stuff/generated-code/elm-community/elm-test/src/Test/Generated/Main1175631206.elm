module Test.Generated.Main1175631206 exposing (main)

import DecoderTests

import Test.Reporter.Reporter exposing (Report(..))
import Console.Text exposing (UseColor(..))
import Test.Runner.Node
import Test
import Json.Encode

main : Test.Runner.Node.TestProgram
main =
    [     Test.describe "DecoderTests" [DecoderTests.suite] ]
        |> Test.concat
        |> Test.Runner.Node.runWithOptions { runs = Nothing, report = (ConsoleReport Monochrome), seed = Nothing, processes = 2, paths = ["tests/DecoderTests.elm"]}