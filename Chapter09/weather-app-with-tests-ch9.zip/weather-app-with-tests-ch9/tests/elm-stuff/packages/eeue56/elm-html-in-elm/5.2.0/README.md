# elm-html-in-elm


A pure Elm represention of Elm Html. This module has been taken from [elm-server-side-renderer](https://github.com/eeue56/elm-server-side-renderer) and is a pure representation of the Html structure used by VirtualDom. It is designed to allow you to inspect Html nodes

This package is used to support testing with [elm-html-test](http://package.elm-lang.org/packages/eeue56/elm-html-test/latest).

This package is also used to support using Elm as to generate static files for
your site with [elm-static-html](https://github.com/eeue56/elm-static-html)
