# Release notes 

This release adds requested minor features. 

## Changes

**Features:**

- Add HTML id Layout main contents [\#265](https://github.com/debois/elm-mdl/pull/265) ([MarkNijhof](https://github.com/MarkNijhof))

**Documentation:**

- Add message logging to demo [1c8ce7](https://github.com/debois/elm-mdl/commit/1c8ce7e1ae0220eac9505d62540f556c307ea7d5)
- Fix obsolete v7 references  [bdc1f2](https://github.com/debois/elm-mdl/commit/bdc1f298808c7b37bef8728616bdc28c42670a0e)

[Full Changelog](https://github.com/debois/elm-mdl/compare/8.0.1...HEAD)
