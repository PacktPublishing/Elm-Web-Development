Run the Makefile target 'install-hooks' from the elm-mdl root to install git
hooks, like so: 

    > t make install-hooks

